# Sanjeevani-Project
This is Java Gui project that Starts with Fram1.java as main page.
This project basically combines all the 3 components of Medical ie. Patient , Doctor and Pharmacist and has some basic features .
This project is still in working phase and will add more and more features.
Book Appointment and Check Appointment is still in development.
